/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.joseph.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author kaoz_
 */

@Entity
@Table
@NamedQueries({@NamedQuery(name="Course.getAll",query="SELECT e FROM Course e")})
public class Course implements Serializable{
    
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    @Column
    private int courseId;
    @Column
    private String courseName;
    @Column
    private int numCredits;
    @Column
    private int semester;
    @Column
    private int admitedNumStudents;

    public Course(int courseId, String courseName, int numCredits, int semester, int admitedNumStudents) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.numCredits = numCredits;
        this.semester = semester;
        this.admitedNumStudents = admitedNumStudents;
    }

    public int getCourseId() {
        return courseId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public int getNumCredits() {
        return numCredits;
    }

    public void setNumCredits(int numCredits) {
        this.numCredits = numCredits;
    }

    public int getSemester() {
        return semester;
    }

    public void setSemester(int semester) {
        this.semester = semester;
    }

    public int getAdmitedNumStudents() {
        return admitedNumStudents;
    }

    public void setAdmitedNumStudents(int admitedNumStudents) {
        this.admitedNumStudents = admitedNumStudents;
    }
    
    
    
    
    
}
