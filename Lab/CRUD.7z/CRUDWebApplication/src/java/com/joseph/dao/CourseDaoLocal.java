/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.joseph.dao;

import com.joseph.model.Course;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author kaoz_
 */
@Local
public interface CourseDaoLocal {

    void addCourse(Course course);

    void editCourse(Course course);

    void deleteCourse(int course);

    Course getCourse(int course);

    List<Course> getAllCourse();

}
